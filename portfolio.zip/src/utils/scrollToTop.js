const scrollToTop = async () => {
  window.scrollTo({
    top: 0,
    behavior: "smooth",
  });
};

export default scrollToTop;
