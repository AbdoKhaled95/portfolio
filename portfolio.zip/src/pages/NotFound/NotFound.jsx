const Notfound = () => {
  return;
};

export default Notfound;
