import { Typography } from "@mui/material";
import React from "react";

const SectionSubtitle = ({ title }) => {
  return (
    <Typography
      variant="h4"
      sx={{
        textAlign: "start",
        fontSize: { xs: 24, md: 32, lg: 48 },
        py: { xs: "8px", lg: "12px" },
      }}
    >
      {title}
    </Typography>
  );
};

export default SectionSubtitle;
