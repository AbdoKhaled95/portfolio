import { Box, Stack, Typography } from "@mui/material";
import React from "react";
import banner0 from "../../assets/images/banner0.jpg";
import { useMainContext } from "../../context/MainContext";

const Banner = () => {
  const { sectionsRes } = useMainContext();
  const titlesStyle = {
    fontSize: { md: 48, lg: 64 },
    color: "white",
  };
  return (
    <Box
      ref={sectionsRes?.beginningOfPageRef}
      sx={{
        backgroundImage: `url(${banner0})`,
        backgroundAttachment: "fixed",
        backgroundSize: "cover",
        minHeight: "600px",
        height: "100vh",
        width: "100%",
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
      }}
    >
      <Stack spacing={2}>
        <Typography variant="h4" sx={titlesStyle}>
          Hello, I'm
        </Typography>
        <Typography
          variant="h3"
          sx={{
            fontSize: { xs: 48, md: 64, lg: 72 },
            color: "primary.main",
          }}
        >
          Abdo Khaled
        </Typography>
        <Typography variant="h4" sx={titlesStyle}>
          Front End Developer
        </Typography>
      </Stack>
    </Box>
  );
};
export default Banner;
