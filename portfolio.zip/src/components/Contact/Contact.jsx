import { Box, Grid, useTheme } from "@mui/material";
import React from "react";
import MainContainer from "../Section/MainContainer";
import SectionHead from "../Section/SectionHead";
import { useMainThemeContext } from "../../context/MainThemeContext";
import ContactForm from "./ContactForm";

const Contact = () => {
  const { sectionsRes } = useMainThemeContext();

  return (
    <Box ref={sectionsRes?.contactRef}>
      <MainContainer>
        <SectionHead title={"Get In Touch"} />
        <Box>
          <Grid
            container
            spacing={6}
            sx={{
              justifyContent: { xs: "center", lg: "space-between" },
            }}
          >
            <Grid item xs={10} lg={6}>
              <ContactForm />
            </Grid>
          </Grid>
        </Box>
      </MainContainer>
    </Box>
  );
};

export default Contact;
